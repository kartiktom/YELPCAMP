var      express        =                                  require("express");
         app            =                                  express(),
         bodyparser     =                                  require("body-parser"),
         mongoose       =                                  require("mongoose"),
		 flash          =                                  require("connect-flash"),
         localstrategy  =                                  require("passport-local"),
	     passport       =                                  require("passport"),
		 user           =                                  require("./models/user"),
		 methodoverride =                                  require("method-override");

mongoose.connect("mongodb+srv://kartik:kartik@1@yelpcamp-wkvhc.mongodb.net/kartik?retryWrites=true&w=majority",{useNewUrlParser:true, useUnifiedTopology: true});


var campground=require("./models/campgrounds.js"),
	seedDB=require("./seeds.js"),
	comment=require("./models/comments");
// seedDB();

app.use(flash());
app.use(methodoverride("_method"));
app.use(express.static(__dirname+"/public"));

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));

app.set("view engine","ejs");

app.use(require("express-session")({
    secret: "Rusty is the best and cutest dog in the world",
   
	resave: false,
    saveUninitialized: false
}));

app.locals.moment = require('moment');

app.use(passport.initialize());
app.use(passport.session());

passport.use(new localstrategy(user.authenticate()));
passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());

app.use(function(req,res,next)
	   {
	res.locals.currentuser=req.user;
	res.locals.error=req.flash("error");
	res.locals.success=req.flash("success");
	next();
})

//===============
//ROUTES
//==================
var campgroundroutes=require("./routes/campgrounds");
app.use("/campgrounds",campgroundroutes);

// ==================================
// 	COMMENTS ROUTE
// ===================================
var commentsroutes=require("./routes/comments");
app.use("/campgrounds/:id/comments",commentsroutes);

//AUTH ROUTES
var auth=require("./routes/index");
app.use(auth);

app.listen(process.env.PORT,process.env.IP,function()
{
    console.log("Server has started!!")
});