var express=require("express");
var app=express.Router({mergeParams:true});
var campground=require("../models/campgrounds");
var comments=require("../models/comments");
var middleware=require("../middleware/index")

//NEW COMMENT FORM
app.get("/new",middleware.isLoggedIn,function(req,res)
	   {
	campground.findById(req.params.id,function(err,campground)
					   {
		if(err)
			console.log(err);
		else
		res.render("comments/new",{campground:campground})	
	})
})

//ADD COMMENTS
app.post("/",middleware.isLoggedIn,function(req,res)
		{
	campground.findById(req.params.id,function(err,campground)
					   {
		if(err)
			res.redirect("/campgrounds");
		else
			{
				comments.create(req.body.comment,function(err,comment)
							  {
					if(err)
						console.log(err);
					else
						{
							
							//add username
							comment.author.id=req.user.id;
							comment.author.username=req.user.username;
							comment.save();
							
						      campground.comments.push(comment);
							campground.save();
							req.flash("success","Successfully added Comment");
							console.log(comment)
							
							res.redirect("/campgrounds/"+campground.id);
						}
				})
			}
	})
})

//EDIT
app.get("/:commentid/edit",middleware.checkcommentownership,function(req,res)
	   {
	comments.findById(req.params.commentid,function(err,foundcomment){
		if(err)
			res.redirect("back");
		else
			res.render("comments/edit",{campground_id: req.params.id,comment:foundcomment})
	})
	
})

app.put("/:commentid",middleware.checkcommentownership,function(req,res)
	   {
	comments.findByIdAndUpdate(req.params.commentid,req.body.comment,function(err,updatedcomment)
							  {
		if(err)
			res.redirect("back");
		else
			res.redirect("/campgrounds/"+req.params.id);
	})
})

//destroy route
app.delete("/:commentid",middleware.checkcommentownership,function(req,res)
		  {
	  comments.findByIdAndRemove(req.params.commentid,function(err)
								{
		  req.flash("success","Comment deleted");
		  res.redirect("/campgrounds/"+req.params.id)
	  })
})

//MIDDLEWARE


module.exports=app;