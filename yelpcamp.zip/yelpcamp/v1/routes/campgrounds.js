
var express=require("express");
var app=express.Router();
var campground=require("../models/campgrounds");
var comments=require("../models/comments");
var middleware=require("../middleware/index")

//campgrounds page
app.get("/",function(req,res){
	var noMatch=null;
	if(req.query.search)
		{
			const regex = new RegExp(escapeRegex(req.query.search), 'gi');
			campground.find({name: regex},function(err,allcamp) {
		if(err)
			console.log("ERROR");
		else
			{
				if(allcamp.length < 1) {
                  noMatch = "No campgrounds match that query, please try again.";
              }
			 res.render("campgrounds/campgrounds",{campgrounds:allcamp,noMatch:noMatch})
			}
	})
		}
	else
		{
	campground.find({},function(err,allcamp) {
		if(err)
			console.log("ERROR");
		else
			{ 
				res.render("campgrounds/campgrounds",{campgrounds:allcamp, noMatch:noMatch });
			}
	})
		}
})

//ADD Campgrounds
app.post("/",middleware.isLoggedIn,function(req,res)
		{
	var name=req.body.name;
	var price=req.body.price;
	var image=req.body.image;
	var desc=req.body.description;
	var author={
		id:req.user.id,
		username:req.user.username
	}
		var newcamp={name:name,price:price,image:image,description:desc,author:author};
	campground.create(newcamp,function(err,newlycreated)
					 {
		if(err)
			console.log(err);
		else
			{
			req.flash("success","Successfully added Campground");
			res.redirect("/campgrounds");
			}
	})
});

//ADD NEW CAMPGROUNDS
app.get("/new",middleware.isLoggedIn,function(req,res)
	   {
	res.render("campgrounds/new.ejs");
});

//Show specific Campgrounds
app.get("/:id",function(req,res)
	   {
	campground.findById(req.params.id).populate("comments").exec(function(err,campground)
					   {
		if(err)
			console.log(err);
		else
			{
				res.render("campgrounds/show",{campground:campground});
			}
	})
})

//EDIT
app.get("/:id/edit",middleware.checkcampgroundownership,function(req,res)
	   {
   campground.findById(req.params.id,function(err,foundcampground) {
		                if(err)
			               res.redirect("/campgrounds");
		               else
							 {
	                            res.render("campgrounds/edit",{campground:foundcampground});
							 }
})
})

//UPDATE
app.put("/:id",middleware.checkcampgroundownership,function(req,res)
	   {
	campground.findByIdAndUpdate(req.params.id,req.body.campground,function(err,updatedcampground)
								{
		if(err)
			res.redirect("/campgrounds");
		else
			res.redirect("/campgrounds/"+req.params.id);
	})
})

//DESTROY CAMPGROUNDS
app.delete("/:id",middleware.checkcampgroundownership,function(req,res)
		  {
			campground.findByIdAndRemove(req.params.id,function(err)
								{
			res.redirect("/campgrounds");
	})
})

function escapeRegex(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};

module.exports=app;
