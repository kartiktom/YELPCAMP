var express=require("express");
var app=express.Router();
var passport=require("passport");
var user=require("../models/user")
var campground=require("../models/campgrounds")


//LANDING PAGE
app.get("/",function(req,res)
	   {
	res.render("landing");
})

//REGISTER USER
app.get("/register",function(req,res)
	   {
	res.render("register");
	
})
app.post("/register",function(req,res)
		{
	var newuser=new user({
		username:req.body.username,
		firstname:req.body.firstname,
		lastname:req.body.lastname,
		email:req.body.email,
		avatar:req.body.avatar
	});
	if(req.body.admincode==='kartikbest')
		newuser.isadmin=true;
	user.register(newuser,req.body.password,function(err,user)
				 {
		if(err)
			{
				req.flash("error",err.message);
			return res.redirect("/register");
			}
		else
			{
				passport.authenticate("local")(req,res,function()
											  {
					req.flash("success","Welcome to Yelp Camp "+user.username);
					res.redirect("/campgrounds");
				})
			}
	})
})


//LOGIN
app.get("/login",function(req,res)
	   {
	res.render("login");
})


app.post("/login",passport.authenticate("local",
	{
	successRedirect:"/campgrounds",
	failureRedirect:"/login"
}),function(req,res){
	
})


//LOGOUT
app.get("/logout", function(req, res){
    req.logout();
	req.flash("success","Logged You Out");
    res.redirect("/campgrounds");
});

//USER PROFILE

app.get("/users/:id", function(req, res) {
  user.findById(req.params.id, function(err, foundUser) {
    if(err) {
      req.flash("error", "Something went wrong.");
      return res.redirect("/");
    }
    campground.find().where('author.id').equals(foundUser._id).exec(function(err, campgrounds) {
      if(err) {
        req.flash("error", "Something went wrong.");
        return res.redirect("/");
      }
      res.render("users/show", {user: foundUser, campgrounds: campgrounds});
    })
  });
});


module.exports=app;
